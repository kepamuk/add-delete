import { SquareSchema } from "../../../../entities/Squares";

export interface StateSchema {
    squares: SquareSchema;
}