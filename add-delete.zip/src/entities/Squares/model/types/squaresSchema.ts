export interface ISquare {
    id: string;
    color: string;
}

export type SquareSchema = ISquare[];